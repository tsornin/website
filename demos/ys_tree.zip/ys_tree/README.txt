Bruno Li - CS 384G Final Project
"Physically Based Animation of L-system Plants"

Instructions:
	Press C to grow a tree. The tree can be manipulated using the cursor.

Controls:
Game:
	Esc, End - exit state
	Home - reset state
	F11 - full screen
	F12 - toggle physics display

Physics:
	Left mouse drag - destroy constraints
	Right mouse drag - grab points

Camera:
	E - cycle targets
	WASD - movement (while untargeted)
	G - freeze
	J, mouse scroll up - zoom out
	K, mouse scroll up - zoom in

The camera target ID is displayed inside square brackets the title bar.
Cycle targets using E or Q:
[1] - bamboo tree
[2] - "D" tree
[3] - random tree
[4] - rain emitter

Trees:
	Arrow keys - move anchor mass
	Z - freeze anchor mass
	C - grow

Emitters:
	Arrow keys - move
	Z - emit toggle
	X - emit hold
